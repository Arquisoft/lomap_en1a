import { Group } from "./Group";
import { Picture } from "./Picture";
import { Place } from "./Place";
import { Score } from "./Score";

export class User {

    #username: string;
    #password: string;
    #podId: string;

    #places: Place[] = [];

    #comments: Comment[] = [];
    #scores: Score[] = [];
    #pictures: Picture[] = [];

    #friends: User[] = [];
    #groups: Group[] = [];


    public constructor(username: string, password: string, podId: string) {
        this.#username = username;
        this.#password = password;
        this.#podId = podId;
    }

    public setUsername(username: string) {
        this.#username = username;
    }

    public getUsername(): string {
        return this.#username;
    }

    public setPassword(password: string) {
        this.#password = password;
    }

    public getPassword(): string {
        return this.#password;
    }

    public setPodId(podId: string) {
        this.#podId = podId;
    }

    public getPodId(): string {
        return this.#podId;
    }

    public addPlace(place: Place) {
        this.#places.push(place);
    }

    public loadPlaces(places: Place[]) {
        this.#places = places;
    }

    public addComment(comment: Comment) {
        this.#comments.push(comment);
    }

    public loadComments(comments: Comment[]) {
        this.#comments = comments;
    }

    public addPicture(picture: Picture) {
        this.#pictures.push(picture);
    }

    public loadPictures(pictures: Picture[]) {
        this.#pictures = pictures;
    }

    public addScore(score: Score) {
        this.#scores.push(score);
    }

    public loadScores(scores: Score[]) {
        this.#scores = scores;
    }

    public addFriend(friend: User) {
        this.#friends.push(friend);
    }

    public loadUsers(friends: User[]) {
        this.#friends = friends;
    }

    public addGroup(group: Group) {
        this.#groups.push(group);
    }

    public loadGroups(groups: Group[]) {
        this.#groups = groups;
    }
}