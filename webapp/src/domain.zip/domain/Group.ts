import { User } from "./User";
import { GroupVisibility } from "./Visibility";

export class Group {

    #name: string;
    #visibility: GroupVisibility;

    #users: User[] = [];

    public constructor(name: string, visibility: GroupVisibility) {
        this.#name = name;
        this.#visibility = visibility;
    }

    public setName(name: string) {
        this.#name = name;
    }

    public getName(): string {
        return this.#name;
    }

    public setVisibility(visibility: GroupVisibility) {
        this.#visibility = visibility;
    }

    public getVisibility(): GroupVisibility {
        return this.#visibility;
    }

    public isVisibleFor(user: User): boolean {
        return this.#visibility.isVisibleFor(user);
    }

    public addUser(user: User) {
        this.#users.push(user);
    }

}