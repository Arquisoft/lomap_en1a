import { User } from "./User";

export interface PlaceVisibility {
    isVisibleFor(user: User): boolean;
}

export interface GroupVisibility {
    isVisibleFor(user: User): boolean;
}